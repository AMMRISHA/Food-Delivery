<!-- social Section Starts Here -->
<section class="social">
        <div class="container text-center">
            <ul>
                    <a href="#"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
                    <a href="#"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"/></a>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
            
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>