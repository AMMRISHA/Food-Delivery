
<?php
    include('partials/menu.php');
?>
        <div class="Main-Content">
            <div class="wrapper">
                <h1>DASHBOARD</h1>

                <div class="col-4 text-center">
                    <h1>1</h1>
                    <br>
                    Categories
                </div>

                <div class="col-4 text-center">
                    <h1>5</h1>
                    <br>
                    Categories
                </div>

                <div class="col-4 text-center">
                    <h1>5</h1>
                    <br>
                    Categories
                </div>

                <div class="col-4 text-center">
                    <h1>5</h1>
                    <br>
                    Categories
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
<?php
    include("partials/footer.php");
?>

        