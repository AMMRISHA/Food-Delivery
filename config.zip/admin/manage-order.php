<?php
    include('partials/menu.php');
?>

<link rel="stylesheet" href="admin.css">
        <div class="Main-Content">
            <div class="wrapper">
                <h1>MANAGE-ORDER</h1>

                <table class="tbl-full">
                    <tr>
                        <th>S.N</th>
                        <th>Food Name</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Actions</th>
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td>Briyani</td>
                        <td>Sharmistha Das</td>
                        <td>Sharmisthadas@gmail.com</td>
                      

                        <td>
                            <a href="#" class="btn-secondary">Conformation message</a>
                            <a href="#" class="btn-denger">Delete Order</a>
                        </td>
                    </tr>

                    <tr>
                        <td>2.</td>
                        <td>Briyani</td>
                        <td>Nitu Naru</td>
                        <td>nitunaru@gmail.com</td>
                        
                        <td>
                            <a href="#" class="btn-secondary">Conformation message</a>
                            <a href="#" class="btn-denger">Delete Order</a>
                        </td>
                    </tr>

                    <tr>
                        <td>3.</td>
                        <td>Snacks</td>
                        <td>Mampi Neye</td>
                        <td>mampineye@gmail.com</td>
                        <td>
                            <a href="#" class="btn-secondary">Conformation message</a>
                            <a href="#" class="btn-denger">Delete Order</a>
                        </td>
                    </tr>

                </table>
                
                
                <div class="clearfix"></div>
            </div>
        </div>

<?php
    include("partials/footer.php");
?>
