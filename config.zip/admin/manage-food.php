<?php
    include('partials/menu.php');
?>

<link rel="stylesheet" href="admin.css">
        <div class="Main-Content">
            <div class="wrapper">
                <h1>MANAGE-FOOD</h1>
                <br/>
            <!-- Button to Add Food -->

            <a href="#" class="btn-primary">Add Food</a>

            <br/>
            <br/>

            <br/>
            <br/>
                <table class="tbl-full">
                    <tr>
                        <th>S.N</th>
                        <th>Food Name</th>
                        <th>Price(₹)</th>
                       
                    </tr>
                    <tr>
                        <td>1.</td>
                        <td>Briyani</td>
                        <td>200</td>
                        <td>
                            <a href="#" class="btn-secondary">Update Food</a>
                            <a href="#" class="btn-denger">Delete Food</a>
                        </td>
                    </tr>

                    <tr>
                        <td>2.</td>
                        <td>Fried Rice</td>
                        <td>200</td>
                        <td>
                            <a href="#" class="btn-secondary">Update Food</a>
                            <a href="#" class="btn-denger">Delete Food</a>
                        </td>
                    </tr>

                    <tr>
                        <td>3.</td>
                        <td>Chicken Curry</td>
                        <td>100</td>
                        <td>
                            <a href="#" class="btn-secondary">Update Food</a>
                            <a href="#" class="btn-denger">Delete Food</a>
                        </td>
                    </tr>

                </table>
                
                <div class="clearfix"></div>
            </div>
        </div>

<?php
    include("partials/footer.php");
?>
