<?php
session_start();
// connect to database
    define('SITEURL', 'http://localhost/project/');
    $server = "localhost";
    $username = "root";
    $password = ""; //To be completed if you have set a password to root
    $database = "project"; //To be completed to connect to a database. The database must exist.

    $conn = mysqli_connect($server,$username,$password,$database);

    /* if (!$conn) 
    {
        die("Sorry we faild to connect:". mysqil_connect_error());
    }
    else
    {
        echo "Connection Was Successful";
    }*/
?>
<html>
    <head>
        <title>Food Order Website - Home page</title>

        <link rel="stylesheet" href="../css/admin.css">
    </head>

    <body>
        <div class="menu text-center">
            <div class="wrapper">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="manage-admin.php">Admin</a></li>
                    <li><a href="manage-category.php">Category</a></li>
                    <li><a href="manage-food.php">Food</a></li>
                    <li><a href="manage-order.php">Order</a></li>
                </ul>
            </div>
        </div>
    </body>
</html>