<html>
    <body>
        <div class="footer">
            <div class="wrapper">
                <p class="text-center">2020 All rights reserved.</p>
            </div>
        </div>
    </body>
</html>