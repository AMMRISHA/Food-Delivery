<?php
    include('partials/menu.php');
?>




        <div class="Main-Content">
            <div class="wrapper">
                <h1>MANAGE-CATEGORY</h1>

                
                <div class="clearfix"></div>
            </div>
        </div>







<?php
    include("partials/footer.php");
?>